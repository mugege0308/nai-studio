# NAI Prompt Studio v13 — PC/スマホ同期＋ダウンロード不要更新

## できること

- GitHub Pages で同じURLを開く。更新した `index.html` / `cloud-sync.js` をGitHubにアップロード・pushすると公開サイトが更新される。利用者は毎回HTMLやZIPをダウンロードし直す必要なし（新バージョンを確認するにはページを更新）。
- Firebase Authentication（メールアドレス＋パスワード）と Realtime Database で、同じログインのPC/スマホ間に編集設定・画像付き保存セット・絵柄プリセット・タグのお気に入りを同期。
- 同期設定前はローカル版として従来どおり使える。
- 画像は**圧縮したサムネイル**だけ。原寸画像、NovelAIの生成履歴やシード情報は同期されない。

## ① GitHub Pagesでサイトを公開

1. GitHubでリポジトリを作る（例：`nai-prompt-studio`）。公開サイト自体はインターネットで閲覧できるため、**秘密の生成画像・プロンプト・アカウント情報はGitHubにアップロードしない**。
2. このフォルダ内の `index.html`、`cloud-sync.js`、`firebase-config.js`、`manifest.json`、`.nojekyll` をリポジトリのルートに追加してコミット。
3. GitHubリポジトリの **Settings → Pages → Build and deployment → Source: Deploy from a branch → Branch: main / (root) → Save**。
4. `https://あなたのGitHubユーザー名.github.io/nai-prompt-studio/` などのURLでサイトが表示される。
5. 次回から修正時は対象ファイルを**同じリポジトリに上書きコミット／push**するだけ。GitHub Pagesが公開版を更新するので、PC・スマホは同じURLを再読み込みすればよい。

GitHub Pagesのリポジトリは**通常パブリック**。アプリのソースコードだけを置き、保存した個人データ・画像を置かないこと。

## ② Firebaseの準備

1. [Firebase Console](https://console.firebase.google.com/) で新しいプロジェクトを作る。
2. プロジェクトの **Authentication → Sign-in method → メール / パスワード** を有効化。
3. **Realtime Database** を作成。アクセス制限は必ず下の**③セキュリティルール**を設定する。
4. プロジェクト設定 → **ウェブアプリの追加（`</>` マーク）** → SDK設定の Firebase config を取得。
5. `firebase-config.js` を開き、`window.NAI_FIREBASE_CONFIG = null;` を、ウェブアプリの設定オブジェクトに置き換える。**Realtime Databaseに表示される `databaseURL` も必要**。編集したファイルをGitHubの同じ場所にコミットする。
6. `index.html` を開くと「クラウド同期」にログイン欄が出る。PCでアカウントを作成し、スマホでは**同じアカウント**でログイン。

Firebase Web API Key (`apiKey`) はブラウザで使うための**公開用設定値**であり、それ自体は管理者の秘密鍵ではない。ただし、**サービスアカウントのJSON秘密鍵、管理者SDK鍵、パスワード**は一切GitHubに置かない。

## ③ Realtime Databaseセキュリティルール（必須）

Realtime Database → **ルール** に、付属の `database.rules.json` の内容を貼り付け、**公開**を押す。

```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "auth != null && auth.uid === $uid",
        ".write": "auth != null && auth.uid === $uid"
      }
    }
  }
}
```

これで `/users/{uid}/...` はログインした本人だけが読み書きできる。**テストモード（誰でも読み書き可能）のまま運用しない**。

## ④ 初回のデータ移行

1. PCのv12で「プリセット設定を書き出す」から **JSONバックアップ**を保存。
2. 公開URLでv13を開き、JSONを取り込み、同期用アカウントにログイン。
3. **「この端末の設定をクラウドに保存」** を選択（初回だけ）。
4. スマホで同じ公開URLを開き、同じアカウントでログイン。
5. **「クラウドの設定をこの端末に読み込む」** を選択。以後は通常の編集・保存で自動同期。

**注意：既存のv12をPCで開いていたときの`localStorage`は、公開URLに自動で移行されない。最初のJSONの書き出し・読み込みが必要。**

## 運用と注意

- 使い方は既存のv12と同じ。3分割コピー・男女/女の子2人・TXT再読み込み・画像付き保存を維持。
- 編集中のフォームは少し後に同期。保存セットの追加・削除・画像差し替えは自動同期。**オフライン時の編集や同時編集では競合の可能性あり**。大切な設定はJSONバックアップ。
- Realtime Databaseはクラウド側の利用量・通信量に応じて料金が発生する場合がある。Firebaseコンソールで利用枠と料金プランを確認。
- 外部Firebase SDKのロード・メールログイン・同期にはインターネットが必要。ローカル編集はそれなしでも使用できる。
- FirebaseプロジェクトとGitHubリポジトリは利用者自身のアカウントで作成する必要がある。**この配布物だけでは公開URLや同期サービスは稼働しない**。
